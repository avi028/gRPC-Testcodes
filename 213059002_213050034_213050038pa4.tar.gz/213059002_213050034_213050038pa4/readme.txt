Team Information:

Arnav Mishra : 213059002
Ajinkya Tanksale : 213050034
Vedant Singh : 213050038


Steps to build and run the server and client
1) Put the folder in grpc/examples/cpp
2) cd KeyValueStore
3) mkdir -p cmake/build
4) pushd cmake/build
5) cmake -DCMAKE_PREFIX_PATH=$MY_INSTALL_DIR ../.. 
6) make
7) Open two terminals and write commands 
./server in first and ./client in second
8) For exiting server press (clt+c) 2 time.


